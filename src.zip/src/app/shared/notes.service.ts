import { Injectable } from '@angular/core';
import {Note} from './note-model'
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NotesService {
  [x: string]: any;

  url="http://localhost:1050/getNotes"

  url2="http://localhost:1050/addNote"



  notes:Note[] = new Array<Note>();
  updateNoteObj:Note;


  constructor(private http:HttpClient) { }

  getNotes():Observable<Note[]>{
    return this.http.get<Note[]>(this.url)
  }

  addNote(data:any):Observable<any>{
    return this.http.post<Observable<any>>(this.url2,data)
  }

  deleteNote(Id:any):Observable<any>{
    return this.http.delete('http://localhost:1050/delete/'+Id)
  }

  updateNote(id, data):Observable<any>{
    return this.http.put('http://localhost:1050/update/'+id , data)
  }

}
