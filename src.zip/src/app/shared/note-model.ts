export class Note{
    public noteId:number;
    public title:string;
    public body:string;
}