import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotesDetailsComponent } from './notes-details/notes-details.component';
import { NotesListComponent } from './notes-list/notes-list.component';
import { UpdateNoteComponent } from './update-note/update-note.component';


const routes: Routes = [
  {path:'',component:NotesListComponent},
  {path:'new',component:NotesDetailsComponent},
  {path:'update/:id/:title/:body',component:UpdateNoteComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
