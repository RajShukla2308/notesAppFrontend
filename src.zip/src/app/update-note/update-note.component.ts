import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Note } from '../shared/note-model';
import { NotesService } from '../shared/notes.service';
import {ActivatedRoute} from '@angular/router'
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-update-note',
  templateUrl: './update-note.component.html',
  styleUrls: ['./update-note.component.css']
})
export class UpdateNoteComponent implements OnInit {

  note:Note;
  titleName:String;
  body:String;
  errorMessage : string;
  noteForm:FormGroup

  constructor(private notesService:NotesService,private router:Router,private Accroute:ActivatedRoute,private fb:FormBuilder) { 
    this.Accroute.params.subscribe(data=>{
      this.titleName = data.title
      this.body = data.body
    })
   }

  ngOnInit(): void {
    this.noteForm = this.fb.group({
      titleName:this.titleName,
      body:this.body
    })
  }

  onSubmit(form:any){
    let id=this.Accroute.snapshot.params.id
    this.notesService.updateNote(id,form.value).subscribe(data=>{
      this.router.navigate(['/'])
    },(err)=>{
      this.errorMessage = err.error.message
    }
    )
  } 
  
  cancel(){
    this.router.navigate(['/'])
  }

}
