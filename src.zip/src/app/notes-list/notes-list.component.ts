import { importExpr } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {Note} from '../shared/note-model';
import {NotesService} from '../shared/notes.service'

@Component({
  selector: 'app-notes-list',
  templateUrl: './notes-list.component.html',
  styleUrls: ['./notes-list.component.css']
})
export class NotesListComponent implements OnInit {

  notes:Note[] = new Array<Note>();
  success:string;
  error:string

  constructor(private notesService:NotesService , private router:Router) { 
    this.notesService.getNotes().subscribe(data=>{
      this.notes = data
    })
   }

  ngOnInit(): void {
    
  }


  myFunction(i:any){
    var r=confirm("are you sure want to delete note?")
    if (r==true){
      this.notesService.deleteNote(i).subscribe(data=>{
        this.notesService.getNotes().subscribe(data=>{
          this.notes = data
        })
      },err=>{
        this.error =err
      })
    }
  }

  delete(i:any){
    this.notesService.delete(i)
  }

  onClick(){
    this.router.navigate(['/new'])
  }

  update(id,title,body){ 
    this.router.navigate(['/update',id,title,body])
  }

}
