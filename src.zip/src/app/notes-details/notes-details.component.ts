import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Note } from '../shared/note-model';
import { NotesService } from '../shared/notes.service';
import {NgForm} from '@angular/forms'

@Component({
  selector: 'app-notes-details',
  templateUrl: './notes-details.component.html',
  styleUrls: ['./notes-details.component.css']
})
export class NotesDetailsComponent implements OnInit {

  note:Note;
  titleName:String;
  body:String;
  errorMessage : string;

  constructor(private notesService:NotesService,private router:Router,private route:Router) { }

  ngOnInit(): void {

  }

  onSubmit(form:NgForm){  
    this.errorMessage=""
    this.notesService.addNote(form.value).subscribe(data=>{
      this.router.navigate(['/'])
    },(err)=>{
      this.errorMessage = err.error.message
    }
    )
  } 
  
  cancel(){
    this.router.navigate(['/'])
  }

}
